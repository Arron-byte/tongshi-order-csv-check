<?php
/**
 * Original, fictional consulting-studio sample. For an isolated Playground only.
 * Run with TONGSHI_SAMPLE_IMPORT=true; no public HTTP import endpoint is enabled.
 */
if (!defined('TONGSHI_SAMPLE_IMPORT') || TONGSHI_SAMPLE_IMPORT !== true) {
    http_response_code(403);
    exit('Sample import is disabled for this request.');
}

require '/wordpress/wp-load.php';

$sample_marker = 'tongshi-cedar-field-v1';
$sample_theme = wp_get_theme('kadence');
if (!$sample_theme->exists()) {
    throw new RuntimeException('Install the Kadence theme before importing this sample.');
}
if (!WP_Block_Type_Registry::get_instance()->is_registered('kadence/advancedheading')) {
    throw new RuntimeException('Activate Kadence Blocks before importing this sample.');
}
$sample_css = file_get_contents(__DIR__ . '/sample.css');
if ($sample_css === false || strlen($sample_css) < 100) {
    throw new RuntimeException('The complete sample.css must sit next to fixture.php.');
}

function cf_sample_block($name, $attrs, $html) {
    return get_comment_delimited_block_content($name, $attrs, "\n" . $html . "\n") . "\n";
}

function cf_sample_p($text, $class = '') {
    $attrs = $class ? array('className' => $class) : array();
    $class_attr = $class ? ' class="' . esc_attr($class) . '"' : '';
    return cf_sample_block('core/paragraph', $attrs, '<p' . $class_attr . '>' . $text . '</p>');
}

function cf_sample_heading($text, $level = 2, $class = '') {
    $attrs = array('level' => $level);
    if ($class) {
        $attrs['className'] = $class;
    }
    return cf_sample_block('core/heading', $attrs, '<h' . $level . ' class="wp-block-heading' . ($class ? ' ' . esc_attr($class) : '') . '">' . $text . '</h' . $level . '>');
}

function cf_sample_title($text, $unique_id) {
    // Matches Kadence Advanced Text's native save markup; its text stays editable.
    $attrs = array(
        'uniqueID' => $unique_id,
        'level' => 1,
        'htmlTag' => 'heading',
        'linkStyle' => '',
        'className' => 'cf-title',
        'googleFont' => false,
        'loadGoogleFont' => false,
    );
    return cf_sample_block('kadence/advancedheading', $attrs,
        '<h1 class="kt-adv-heading' . esc_attr($unique_id) . ' cf-title wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading' . esc_attr($unique_id) . '">' . $text . '</h1>');
}

function cf_sample_group($content, $class = '') {
    $attrs = array('className' => $class, 'layout' => array('type' => 'default'));
    return cf_sample_block('core/group', $attrs, '<div class="wp-block-group ' . esc_attr($class) . '">' . "\n" . $content . '</div>');
}

function cf_sample_button($text, $url, $outline = false) {
    $attrs = $outline ? array('className' => 'is-style-outline') : array();
    return cf_sample_block('core/button', $attrs,
        '<div class="wp-block-button' . ($outline ? ' is-style-outline' : '') . '"><a class="wp-block-button__link wp-element-button" href="' . esc_url($url) . '">' . esc_html($text) . '</a></div>');
}

function cf_sample_buttons($buttons) {
    return cf_sample_block('core/buttons', array('className' => 'cf-actions'), '<div class="wp-block-buttons cf-actions">' . "\n" . $buttons . '</div>');
}

function cf_sample_card($kicker, $title, $description, $extra = '') {
    return cf_sample_group(cf_sample_p(esc_html($kicker), 'cf-kicker') . cf_sample_heading(esc_html($title), 3) . cf_sample_p($description) . $extra, 'cf-card');
}

function cf_sample_intro($label, $title, $description, $slug) {
    return cf_sample_group(cf_sample_p(esc_html($label), 'cf-kicker') . cf_sample_title($title, 'cf-' . $slug) . cf_sample_p($description, 'cf-lead'), 'cf-intro');
}

function cf_sample_footer($urls) {
    $links = '<a href="' . esc_url($urls['home']) . '">Cedar &amp; Field</a> <span aria-hidden="true">/</span> <a href="' . esc_url($urls['services']) . '">Services</a> <span aria-hidden="true">/</span> <a href="' . esc_url($urls['contact']) . '">Contact</a>';
    return cf_sample_group(cf_sample_p($links, 'cf-footer-links') . cf_sample_p('A fictional studio sample by Tongshi AI, with original copy and demonstration content.', 'cf-sample-note'), 'cf-footer');
}

$sample_titles = array('home' => 'Home', 'services' => 'Services', 'method' => 'Method', 'about' => 'About', 'example' => 'Example', 'contact' => 'Contact');
$sample_existing = array();
foreach ($sample_titles as $slug => $title) {
    $existing = get_page_by_path($slug, OBJECT, 'page');
    if ($existing && get_post_meta($existing->ID, '_tongshi_sample', true) !== $sample_marker) {
        throw new RuntimeException('Refusing to replace an unrelated page: ' . $slug);
    }
    $sample_existing[$slug] = $existing;
}

switch_theme('kadence');
update_option('blogname', 'Cedar & Field');
update_option('blogdescription', 'Practical clarity for growing teams');
$sample_admin = get_user_by('login', 'admin');
if ($sample_admin) {
    update_user_meta($sample_admin->ID, 'show_admin_bar_front', 'false');
}
update_option('blog_public', 0);
update_option('show_on_front', 'page');
update_option('permalink_structure', '/%postname%/');

$sample_ids = array();
foreach ($sample_titles as $slug => $title) {
    $post = array('post_type' => 'page', 'post_name' => $slug, 'post_title' => $title, 'post_status' => 'publish', 'comment_status' => 'closed', 'ping_status' => 'closed');
    if ($sample_existing[$slug]) {
        $post['ID'] = $sample_existing[$slug]->ID;
    }
    $id = wp_insert_post($post, true);
    if (is_wp_error($id)) {
        throw new RuntimeException($id->get_error_message());
    }
    update_post_meta($id, '_tongshi_sample', $sample_marker);
    update_post_meta($id, '_kad_post_title', 'hide');
    update_post_meta($id, '_kad_post_layout', 'fullwidth');
    update_post_meta($id, '_kad_post_content_style', 'unboxed');
    $sample_ids[$slug] = $id;
}
update_option('page_on_front', $sample_ids['home']);
$sample_urls = array();
foreach ($sample_ids as $slug => $id) {
    $sample_urls[$slug] = get_permalink($id);
}

$home_copy = cf_sample_p('Clarity for growing teams', 'cf-kicker')
    . cf_sample_title('Good work.<br>Clear direction.', 'cf-home')
    . cf_sample_p('Make the next decision simpler. Build a way of working your team can use every day.', 'cf-lead')
    . cf_sample_buttons(cf_sample_button('Explore our services', $sample_urls['services']) . cf_sample_button('See an example', $sample_urls['example'], true));
$home_notes = cf_sample_p('A working rhythm', 'cf-kicker')
    . cf_sample_heading('Less noise.<br>More forward motion.', 2)
    . cf_sample_group(cf_sample_p('A clear decision', 'cf-note-title') . cf_sample_p('What matters now, and why.'), 'cf-note-row')
    . cf_sample_group(cf_sample_p('A named owner', 'cf-note-title') . cf_sample_p('Someone to carry the next step.'), 'cf-note-row')
    . cf_sample_group(cf_sample_p('A useful review', 'cf-note-title') . cf_sample_p('Evidence to keep, change or stop.'), 'cf-note-row');
$sample_pages['home'] = cf_sample_group(cf_sample_group($home_copy, 'cf-hero-copy') . cf_sample_group($home_notes, 'cf-field-notes'), 'cf-hero')
    . cf_sample_group(cf_sample_p('Where we can help', 'cf-kicker') . cf_sample_heading('Turn a busy week into a workable plan.')
    . cf_sample_group(
        cf_sample_card('Direction', 'Choose the next move', 'Bring priorities, constraints and trade-offs into one practical decision.')
        . cf_sample_card('Operations', 'Make work flow', 'Clarify handoffs, remove duplicate effort and give important tasks an owner.')
        . cf_sample_card('Delivery', 'Keep progress visible', 'Use a short review rhythm and a small set of measures your team understands.'), 'cf-grid cf-grid-three'), 'cf-section')
    . cf_sample_group(cf_sample_heading('Start with one useful question.') . cf_sample_p('A focused brief is often enough to see where the work should begin.') . cf_sample_buttons(cf_sample_button('Shape your brief', $sample_urls['contact'])), 'cf-callout');

$sample_pages['services'] = cf_sample_intro('Services', 'A focused piece of work.<br>A useful next step.', 'Choose a clear starting point. Each engagement is shaped around a decision, a workflow or a delivery challenge.', 'services')
    . cf_sample_group(
        cf_sample_card('Strategy', 'Decision brief', 'Put a consequential choice into context. Compare realistic options and agree the evidence needed to choose.', cf_sample_p('<strong>Working output</strong><br>A concise options paper, a recommendation and the first actions.', 'cf-card-output'))
        . cf_sample_card('Operations', 'Workflow review', 'Follow a piece of work from request to completion. Make handoffs, exceptions and responsibilities visible.', cf_sample_p('<strong>Working output</strong><br>A current-state map, a simpler proposed flow and an ownership checklist.', 'cf-card-output'))
        . cf_sample_card('Delivery', 'Implementation plan', 'Translate an agreed direction into manageable work. Separate the first deliverable from later improvements.', cf_sample_p('<strong>Working output</strong><br>A phased plan with owners, acceptance checks and review points.', 'cf-card-output')), 'cf-grid cf-grid-three')
    . cf_sample_group(cf_sample_heading('Agree the work before starting.') . cf_sample_p('A short written scope sets out the question, inputs, deliverables, timing and review process. Changes are discussed before they become additional work.') . cf_sample_buttons(cf_sample_button('How we work', $sample_urls['method'])), 'cf-callout');

$sample_pages['method'] = cf_sample_intro('Method', 'A simple rhythm<br>for useful change.', 'Understand the situation, make a clear choice and test it in the work itself.', 'method')
    . cf_sample_group(
        cf_sample_card('Discover', 'Understand the real constraint', 'Start with the decision you need to make. Review a small set of relevant documents and listen to the people doing the work.')
        . cf_sample_card('Define', 'Make the scope concrete', 'Write down the desired outcome, assumptions and boundaries. Agree what a useful result will look like.')
        . cf_sample_card('Build', 'Work in visible steps', 'Develop a practical draft. Surface unanswered questions early and keep the reasoning alongside the recommendation.')
        . cf_sample_card('Review', 'Leave a usable handover', 'Walk through the result, record open decisions and leave clear next steps for the team taking it forward.'), 'cf-grid cf-grid-two')
    . cf_sample_group(cf_sample_heading('Clarity includes what is still unknown.') . cf_sample_p('We distinguish evidence from assumptions. When a question cannot be answered from the available material, it stays visible in the handover.'), 'cf-callout');

$sample_pages['about'] = cf_sample_intro('About the studio', 'Practical thinking.<br>Thoughtful delivery.', 'Cedar & Field is an original fictional advisory studio created to demonstrate a clear, editable consulting website.', 'about')
    . cf_sample_group(
        cf_sample_group(cf_sample_heading('Built around the work.') . cf_sample_p('The studio concept brings strategy, operations and delivery into one conversation. The aim is to help a small team move from an unclear problem to a manageable next step.') . cf_sample_p('The language is direct, the process is visible, and the output is something a team can use.'), 'cf-prose')
        . cf_sample_group(cf_sample_p('The principles', 'cf-kicker') . cf_sample_heading('Keep it clear.') . cf_sample_p('<strong>Be specific.</strong><br>Use real questions, concrete examples and plain language.') . cf_sample_p('<strong>Make it usable.</strong><br>Design recommendations around the people carrying them out.') . cf_sample_p('<strong>Show the reasoning.</strong><br>Keep evidence, assumptions and decisions easy to follow.'), 'cf-field-notes'), 'cf-grid cf-grid-two')
    . cf_sample_group(cf_sample_heading('Explore a small example.') . cf_sample_p('See how the studio approach could turn scattered order information into a simple weekly view.') . cf_sample_buttons(cf_sample_button('View the illustrative project', $sample_urls['example'])), 'cf-callout');

$sample_pages['example'] = cf_sample_intro('Illustrative project', 'One clear view<br>of a busy week.', 'A fictional scenario showing how a workflow review could help a small product business organise its order information.', 'example')
    . cf_sample_group(
        cf_sample_card('The situation', 'Information in several places', 'Orders arrive in separate exports. Status labels vary, duplicate records appear, and the weekly summary takes longer than it should.')
        . cf_sample_card('The focused question', 'What needs attention now?', 'Define a repeatable way to identify missing fields, conflicting statuses and repeated order IDs before preparing a summary.'), 'cf-grid cf-grid-two')
    . cf_sample_group(cf_sample_p('A proposed working approach', 'cf-kicker') . cf_sample_heading('Make the exceptions visible first.')
        . cf_sample_group(
            cf_sample_card('Inputs', 'Agree the source', 'Choose one export format, preserve the original file and confirm how each field should be interpreted.')
            . cf_sample_card('Checks', 'Keep the evidence', 'Record the source row for each exception. Keep duplicates visible until their meaning is confirmed.')
            . cf_sample_card('Handover', 'Give the team a routine', 'Provide an issues list, a clearly labelled summary and a short checklist for the next reporting cycle.'), 'cf-grid cf-grid-three'), 'cf-section')
    . cf_sample_group(cf_sample_heading('The intended outcome') . cf_sample_p('A consistent weekly view with open questions clearly marked. This is an illustrative workflow, not a completed client case or a claim of measured results.') . cf_sample_buttons(cf_sample_button('Explore the workflow service', $sample_urls['services'])), 'cf-callout');

$sample_pages['contact'] = cf_sample_intro('Contact', 'Start with the question<br>you need to answer.', 'A useful project brief can be short. Outline the situation, the decision ahead and the material already available.', 'contact')
    . cf_sample_group(
        cf_sample_group(cf_sample_heading('A good first brief')
            . cf_sample_group(cf_sample_heading('What is getting in the way?', 3) . cf_sample_p('Describe the problem in a few sentences, with one concrete example.'), 'cf-brief-row')
            . cf_sample_group(cf_sample_heading('What would a useful result be?', 3) . cf_sample_p('Name the decision, document or working process you want to leave with.'), 'cf-brief-row')
            . cf_sample_group(cf_sample_heading('What can we work from?', 3) . cf_sample_p('List the relevant information, people and constraints. Use anonymised examples when preparing an initial brief.'), 'cf-brief-row'), 'cf-prose')
        . cf_sample_group(cf_sample_p('Before work begins', 'cf-kicker') . cf_sample_heading('A clear agreement.') . cf_sample_p('The scope, deliverables, timing and fee would be agreed in writing before any engagement starts.') . cf_sample_p('This sample has no live enquiry form or mailbox. No information is collected here.', 'cf-contact-note') . cf_sample_buttons(cf_sample_button('Explore a sample brief', $sample_urls['example'])), 'cf-field-notes'), 'cf-grid cf-grid-two');

$sample_report = array('sample' => $sample_marker, 'theme' => $sample_theme->get('Version'), 'pages' => array(), 'contact_is_live' => false);
foreach ($sample_pages as $slug => $content) {
    $content = cf_sample_group($content . cf_sample_footer($sample_urls), 'cf-page');
    $saved = wp_update_post(array('ID' => $sample_ids[$slug], 'post_content' => $content), true);
    if (is_wp_error($saved)) {
        throw new RuntimeException($saved->get_error_message());
    }
    $sample_report['pages'][] = array('slug' => $slug, 'id' => $saved, 'url' => $sample_urls[$slug], 'content_sha256' => hash('sha256', $content));
}

$sample_menu_name = 'Cedar & Field sample navigation';
$sample_menu = wp_get_nav_menu_object($sample_menu_name);
$sample_menu_id = $sample_menu ? $sample_menu->term_id : wp_create_nav_menu($sample_menu_name);
if (is_wp_error($sample_menu_id)) {
    throw new RuntimeException($sample_menu_id->get_error_message());
}
$sample_menu_items = wp_get_nav_menu_items($sample_menu_id) ?: array();
$position = 1;
foreach ($sample_titles as $slug => $title) {
    $existing_item_id = 0;
    foreach ($sample_menu_items as $item) {
        if ($item->object === 'page' && (int) $item->object_id === $sample_ids[$slug]) {
            $existing_item_id = $item->ID;
            break;
        }
    }
    $saved = wp_update_nav_menu_item($sample_menu_id, $existing_item_id, array(
        'menu-item-object-id' => $sample_ids[$slug], 'menu-item-object' => 'page',
        'menu-item-type' => 'post_type', 'menu-item-status' => 'publish',
        'menu-item-title' => $title, 'menu-item-position' => $position++,
    ));
    if (is_wp_error($saved)) {
        throw new RuntimeException($saved->get_error_message());
    }
}
$sample_locations = get_theme_mod('nav_menu_locations', array());
foreach (get_registered_nav_menus() as $location => $label) {
    if (in_array($location, array('primary', 'mobile'), true)) {
        $sample_locations[$location] = $sample_menu_id;
    }
}
set_theme_mod('nav_menu_locations', $sample_locations);
$css_result = wp_update_custom_css_post($sample_css, array('stylesheet' => 'kadence'));
if (is_wp_error($css_result)) {
    throw new RuntimeException($css_result->get_error_message());
}
flush_rewrite_rules(false);
$sample_report['css_sha256'] = hash('sha256', $sample_css);
$sample_report['menu_id'] = $sample_menu_id;
$sample_report['menu_locations'] = $sample_locations;
echo wp_json_encode($sample_report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";
